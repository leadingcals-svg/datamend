"use client";
import { useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase";
export default function AuthForm({ mode }: {mode:"login"|"signup"}) {
 const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [busy,setBusy]=useState(false); const [message,setMessage]=useState("");
 async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setMessage("");
  const supabase=createClient();
  if(!supabase){setMessage("Supabase is not configured yet. Add the values from your Supabase project to .env.local, then restart the app.");setBusy(false);return;}
  const result=mode==="signup"?await supabase.auth.signUp({email,password,options:{emailRedirectTo:location.origin+"/dashboard"}}):await supabase.auth.signInWithPassword({email,password});
  if(result.error)setMessage(result.error.message);
  else if(mode==="signup")setMessage("Account created. Check your email to confirm your address, then sign in.");
  else location.href="/dashboard";
  setBusy(false);
 }
 return <div className="authwrap card"><div className="brand"><div className="brandmark">D</div>DataMend</div><h1>{mode==="login"?"Welcome back":"Create your workspace"}</h1><p className="muted">{mode==="login"?"Sign in to access your saved projects.":"Create an account to save projects across devices."}</p><form onSubmit={submit}><label className="label">Email address</label><input className="input" type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@company.com"/><label className="label">Password</label><input className="input" type="password" minLength={8} required value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters"/><button className="button" style={{width:"100%",marginTop:20}} disabled={busy}>{busy?"Please wait…":mode==="login"?"Sign in":"Create account"}</button></form>{message&&<p className="alert" style={{marginTop:14}}>{message}</p>}<p className="muted" style={{fontSize:13,marginTop:18}}>{mode==="login"?"New to DataMend? ":"Already have an account? "}<Link href={mode==="login"?"/signup":"/login"}>{mode==="login"?"Create an account":"Sign in"}</Link></p></div>;
}
