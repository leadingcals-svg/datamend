export type Cell = string | number | boolean | null;
export type DataRow = Record<string, Cell>;
export type Project = {
  id: string;
  name: string;
  file_name: string;
  row_count: number;
  column_count: number;
  updated_at: string;
  storage_mode: "local" | "cloud";
};
