# DataMend SaaS — Hybrid starter

This is a hosted-web-app foundation for DataMend. It includes a marketing site, signup/sign-in UI, account dashboard, a browser-based CSV/XLSX cleaning workspace, automatic cloud project storage after sign-in, and a Supabase schema with row-level security.

## Important scope / honest status

This is a **deployable SaaS starter**, not a fully production-certified service. Authentication and cloud project metadata work only after you create and configure a Supabase project. The hybrid implementation parses and cleans spreadsheet contents in the browser. When a signed-in user imports or edits a dataset, DataMend debounces changes and automatically uploads the complete table as JSON to that user’s private Supabase Storage folder. The dashboard lists saved projects; selecting a project reopens it for continued editing. Cloud file storage policies, billing, email deliverability configuration, monitoring, backups, legal pages, rate limiting, and production security review remain before public commercial launch.

## Requirements

- Node.js 20 LTS (recommended)
- npm
- Supabase account (free tier can be used for development)
- Vercel account for hosting (optional; local development first)

## Run locally

1. Extract the project.
2. Install Node.js 20 LTS from https://nodejs.org/
3. Open a terminal in this project folder.
4. Run:

   ```bash
   npm install
   copy .env.example .env.local
   npm run dev
   ```

5. Open http://localhost:3000

The public landing page and local workspace work without Supabase. Email/password registration, sign-in, project listing and cloud auto-save require Supabase configuration.

## Configure Supabase

1. Create a project at https://supabase.com/
2. In Project Settings → API, copy the Project URL and anon/public key.
3. Paste them into `.env.local`:

   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
   ```

4. In Supabase → SQL Editor, run the contents of `supabase/schema.sql`.
5. In Authentication → URL Configuration, set the local Site URL to `http://localhost:3000` and add your deployed URL before launch.
6. In Authentication → Providers → Email, keep email/password enabled. Decide whether email confirmation is required and configure SMTP before public launch; default email delivery is for testing only.
7. Restart `npm run dev`.
8. Run the updated `supabase/schema.sql` (it is safe to run after the initial setup script and adds the app-required columns while keeping the `datamend-projects` bucket). Test signup, email confirmation, sign-in, import, wait for auto-save, sign out/in, reopen from the dashboard, edit, wait for auto-save, and verify changes persist.

Never put a Supabase service-role key in a browser environment variable. This app only uses the anon/public key and row-level security.

## Routes

- `/` — marketing landing page
- `/signup` — account registration
- `/login` — sign in
- `/dashboard` — account project overview
- `/workspace` — local file import, profiling, cleaning, preview and CSV export

## Hybrid data model

- Spreadsheet contents are parsed and cleaned in the browser.
- The user can export cleaned CSV locally.
- When signed in, the app automatically saves the complete dataset to a private Supabase Storage bucket after a short debounce. Project metadata is linked to the authenticated Supabase user ID. Reopening a saved project downloads it from private storage and restores the editable table.
- This starter does **not** upload spreadsheet contents to cloud storage. Add explicit, consent-based file storage only after defining retention, deletion, encryption, size limits and privacy policy.

## Before production launch

- Add password reset and robust auth callback handling.
- Add server-side authorization checks to every private route/API.
- Add a user-facing project delete action and retention controls; review autosave consent and data retention wording.
- Add file-size limits, MIME/content validation and robust malformed-file handling.
- Add comprehensive tests for CSV edge cases, formulas, encodings, XLSX sheets and large files.
- Add privacy policy, terms, cookie policy if applicable, contact/support and data deletion flow.
- Configure custom domain, production Supabase redirect URLs, backups, monitoring and error reporting.
- Review all dependencies and licenses.
- Perform a security and accessibility review.
- Do not advertise as production-ready until these checks pass.

## License

See `LICENSE.txt`. Third-party packages retain their own licenses.


## Important: upgrade an existing Supabase project
Before using cloud project saving in an existing Supabase project, open Supabase → SQL Editor and run `supabase/fix_existing_database.sql` in full. This adds the missing `row_count` and `column_count` columns and restores the required private storage policies. Without this migration, saving projects will fail.
