# DataMend SaaS test checklist

## Local run
- [ ] `npm install` completes
- [ ] `npm run dev` starts
- [ ] Landing page renders at `/`
- [ ] Workspace renders at `/workspace`

## File processing
- [ ] Import a clean CSV
- [ ] Import UTF-8 CSV with Croatian characters
- [ ] Import CSV containing blank lines
- [ ] Import CSV with short and long rows
- [ ] Import XLSX (currently first sheet only)
- [ ] Trim whitespace
- [ ] Remove exact duplicate rows
- [ ] Remove completely empty rows
- [ ] Fill blanks in one selected column
- [ ] Undo each operation
- [ ] Export CSV and reopen in Excel

## Supabase (after environment configuration)
- [ ] Signup with email/password
- [ ] Confirm email (if confirmation is enabled)
- [ ] Sign in / sign out
- [ ] User A cannot see User B project records
- [ ] Import a dataset while signed in and wait for automatic cloud save
- [ ] Confirm project appears in dashboard
- [ ] Reopen project and verify headers and rows
- [ ] Edit data and wait for auto-save debounce
- [ ] Refresh/reopen and confirm edits persist
- [ ] User B cannot read or download User A's project or storage object
- [ ] Test deployed redirect URLs and email delivery

## Known limitations / launch work
- Auto-save is debounced in the browser; verify race conditions and large datasets before production.
- Quality score is a simple estimate, not a statistically validated score.
- Duplicate detection compares full rows only.
- XLS/XLSX import currently reads the first worksheet only.
- Add password reset, project deletion, retention controls and clear consent/privacy wording.
- Configure production SMTP, domain, hosting, backups, monitoring and error reporting.
- Add automated unit/end-to-end tests and conduct a security/accessibility review.
- Do not describe this package as production-certified until the checklist is completed.
