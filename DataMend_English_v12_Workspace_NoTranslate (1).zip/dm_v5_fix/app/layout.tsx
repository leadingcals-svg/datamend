import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "DataMend — Clean data. Clear decisions.",
  description: "A private workspace for profiling and cleaning spreadsheet data."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" translate="no" className="notranslate"><head><meta name="google" content="notranslate" /></head><body>{children}</body></html>;
}
