import AuthForm from "@/components/AuthForm";
export default function Login(){return <main className="container"><AuthForm mode="login"/></main>}
