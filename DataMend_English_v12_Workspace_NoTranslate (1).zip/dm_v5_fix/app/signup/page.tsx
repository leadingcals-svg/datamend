import AuthForm from "@/components/AuthForm";
export default function Signup(){return <main className="container"><AuthForm mode="signup"/></main>}
