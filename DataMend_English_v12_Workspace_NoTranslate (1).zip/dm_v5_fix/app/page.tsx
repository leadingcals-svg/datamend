import Link from "next/link";
import { ArrowRight, ShieldCheck, Sparkles, Table2, Cloud, Zap } from "lucide-react";
export default function Home() {
 return <div className="shell">
  <header className="topbar"><div className="brand"><div className="brandmark">D</div>DataMend</div><nav className="navlinks"><a href="#features">Features</a><Link href="/privacy">Privacy</Link><Link className="button secondary" href="/login">Sign in</Link><Link className="button" href="/signup">Get started <ArrowRight size={16}/></Link></nav></header>
  <main className="container">
   <section className="hero"><div><div className="eyebrow">Spreadsheet data quality workspace</div><h1>Messy data in.<br/><span style={{color:"var(--blue)"}}>Clear data out.</span></h1><p>Find duplicates, fix inconsistent values and clean CSV or Excel files in a focused workspace. Start privately in your browser, then save selected projects to your cloud workspace.</p><div className="row" style={{marginTop:25}}><Link className="button" href="/signup">Create free workspace <ArrowRight size={17}/></Link><Link className="button ghost" href="/workspace">Try local workspace</Link></div><p style={{fontSize:12}}>Local processing by default · Cloud saving is optional</p></div>
    <div className="preview"><div className="previewbar"><i className="dot"/><i className="dot"/><i className="dot"/></div><div className="between" style={{marginBottom:18}}><div><div style={{fontSize:12,opacity:.7}}>DATA QUALITY OVERVIEW</div><div style={{font:"800 30px Manrope",marginTop:5}}>94.8%</div></div><span className="pill">+12.4% improved</span></div><div className="previewtable"><div><span>Customer</span><span>Email</span><span>Status</span></div><div><span>Ana Horvat</span><span>ana@email.com</span><span>Complete</span></div><div><span>Marko Novak</span><span style={{color:"#bd7a18"}}>Missing</span><span>Pending</span></div><div><span>Ivana Kovač</span><span>ivana@email.com</span><span>Complete</span></div></div><div style={{display:"flex",gap:10,marginTop:18,fontSize:12,opacity:.8}}><span>✓ Duplicate detection</span><span>✓ Smart suggestions</span></div></div>
   </section>
   <section id="features"><div className="eyebrow">Built for real-world spreadsheets</div><h2 style={{font:"800 30px Manrope",margin:"8px 0"}}>Everything you need to clean with confidence.</h2><div className="featuregrid">
    <div className="card feature"><div className="iconbox"><Table2/></div><h3>Profile your data</h3><p>Understand row counts, missing values, duplicate records and column quality before making changes.</p></div>
    <div className="card feature"><div className="iconbox"><Sparkles/></div><h3>Guided cleaning</h3><p>Review suggested actions such as trimming whitespace, removing duplicates and handling blank rows.</p></div>
    <div className="card feature"><div className="iconbox"><ShieldCheck/></div><h3>Private by default</h3><p>Files are processed in your browser. Choose explicitly when to save a project to your account.</p></div>
    <div className="card feature"><div className="iconbox"><Cloud/></div><h3>Optional cloud projects</h3><p>Save project metadata and a working copy to your private cloud workspace when you need cross-device access.</p></div>
    <div className="card feature"><div className="iconbox"><Zap/></div><h3>Fast exports</h3><p>Export cleaned data to CSV or Excel-compatible files for the tools your team already uses.</p></div>
    <div className="card feature"><div className="iconbox">↶</div><h3>Stay in control</h3><p>Review changes, undo edits and keep the original file available during your cleaning session.</p></div>
   </div></section>
   <section id="privacy" className="card"><div className="row"><ShieldCheck color="var(--green)"/><b>Hybrid privacy model</b></div><p className="muted" style={{lineHeight:1.7}}>DataMend processes imported files locally in the browser. Cloud saving is a separate action. Supabase stores each signed-in user's saved project files in a private cloud workspace.</p></section>
  </main><footer className="footer">© {new Date().getFullYear()} DataMend · Clean data. Clear decisions.</footer>
 </div>;
}
