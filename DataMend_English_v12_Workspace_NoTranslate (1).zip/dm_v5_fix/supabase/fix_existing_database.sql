-- DataMend: run this entire script once in Supabase SQL Editor.
-- It upgrades an EXISTING project created by the earlier DataMend setup.
create extension if not exists pgcrypto;

alter table public.projects
  add column if not exists row_count integer not null default 0,
  add column if not exists column_count integer not null default 0,
  add column if not exists storage_mode text not null default 'cloud',
  add column if not exists storage_path text,
  add column if not exists file_name text,
  add column if not exists summary jsonb not null default '{}'::jsonb,
  add column if not exists updated_at timestamptz not null default now();

alter table public.projects enable row level security;

drop policy if exists "Users can view own projects" on public.projects;
drop policy if exists "Users can create own projects" on public.projects;
drop policy if exists "Users can update own projects" on public.projects;
drop policy if exists "Users can delete own projects" on public.projects;

create policy "Users can view own projects" on public.projects
  for select to authenticated using (auth.uid() = user_id);
create policy "Users can create own projects" on public.projects
  for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update own projects" on public.projects
  for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can delete own projects" on public.projects
  for delete to authenticated using (auth.uid() = user_id);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('datamend-projects','datamend-projects',false,52428800,array['application/json'])
on conflict (id) do update set public=false, file_size_limit=52428800, allowed_mime_types=array['application/json'];

drop policy if exists "Users can view own project files" on storage.objects;
drop policy if exists "Users can upload own project files" on storage.objects;
drop policy if exists "Users can update own project files" on storage.objects;
drop policy if exists "Users can delete own project files" on storage.objects;

create policy "Users can view own project files" on storage.objects
  for select to authenticated using (bucket_id='datamend-projects' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Users can upload own project files" on storage.objects
  for insert to authenticated with check (bucket_id='datamend-projects' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Users can update own project files" on storage.objects
  for update to authenticated using (bucket_id='datamend-projects' and (storage.foldername(name))[1]=auth.uid()::text)
  with check (bucket_id='datamend-projects' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Users can delete own project files" on storage.objects
  for delete to authenticated using (bucket_id='datamend-projects' and (storage.foldername(name))[1]=auth.uid()::text);
