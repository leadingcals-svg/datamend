-- DataMend schema upgrade. Safe to run more than once.
-- Uses the existing private bucket created during setup: datamend-projects.

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null default 'Untitled project',
  data jsonb,
  file_name text,
  file_type text,
  storage_path text,
  row_count integer not null default 0,
  column_count integer not null default 0,
  storage_mode text not null default 'cloud' check (storage_mode in ('local','cloud')),
  summary jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.projects add column if not exists data jsonb;
alter table public.projects add column if not exists file_name text;
alter table public.projects add column if not exists file_type text;
alter table public.projects add column if not exists storage_path text;
alter table public.projects add column if not exists row_count integer not null default 0;
alter table public.projects add column if not exists column_count integer not null default 0;
alter table public.projects add column if not exists storage_mode text not null default 'cloud';
alter table public.projects add column if not exists summary jsonb not null default '{}'::jsonb;
alter table public.projects add column if not exists created_at timestamptz not null default now();
alter table public.projects add column if not exists updated_at timestamptz not null default now();

alter table public.projects enable row level security;
drop policy if exists "Users can view own projects" on public.projects;
drop policy if exists "Users can create own projects" on public.projects;
drop policy if exists "Users can update own projects" on public.projects;
drop policy if exists "Users can delete own projects" on public.projects;
drop policy if exists "Users can read their own projects" on public.projects;
drop policy if exists "Users can insert their own projects" on public.projects;
drop policy if exists "Users can update their own projects" on public.projects;
drop policy if exists "Users can delete their own projects" on public.projects;
create policy "Users can view own projects" on public.projects for select to authenticated using (auth.uid() = user_id);
create policy "Users can create own projects" on public.projects for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update own projects" on public.projects for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can delete own projects" on public.projects for delete to authenticated using (auth.uid() = user_id);
create index if not exists projects_user_updated_idx on public.projects(user_id, updated_at desc);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('datamend-projects', 'datamend-projects', false, 52428800, array['application/json'])
on conflict (id) do update set public = false, file_size_limit = 52428800, allowed_mime_types = array['application/json'];

drop policy if exists "Users can view own project files" on storage.objects;
drop policy if exists "Users can upload own project files" on storage.objects;
drop policy if exists "Users can update own project files" on storage.objects;
drop policy if exists "Users can delete own project files" on storage.objects;
drop policy if exists "Users can read own project files" on storage.objects;
drop policy if exists "Users can upload own project files" on storage.objects;
drop policy if exists "Users can update own project files" on storage.objects;
drop policy if exists "Users can delete own project files" on storage.objects;
create policy "Users can view own project files" on storage.objects for select to authenticated using (bucket_id = 'datamend-projects' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users can upload own project files" on storage.objects for insert to authenticated with check (bucket_id = 'datamend-projects' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users can update own project files" on storage.objects for update to authenticated using (bucket_id = 'datamend-projects' and (storage.foldername(name))[1] = auth.uid()::text) with check (bucket_id = 'datamend-projects' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users can delete own project files" on storage.objects for delete to authenticated using (bucket_id = 'datamend-projects' and (storage.foldername(name))[1] = auth.uid()::text);

-- Compatibility columns used by the DataMend cloud project workspace
ALTER TABLE public.projects
  ADD COLUMN IF NOT EXISTS row_count INTEGER,
  ADD COLUMN IF NOT EXISTS column_count INTEGER,
  ADD COLUMN IF NOT EXISTS storage_mode TEXT DEFAULT 'cloud',
  ADD COLUMN IF NOT EXISTS summary JSONB;
