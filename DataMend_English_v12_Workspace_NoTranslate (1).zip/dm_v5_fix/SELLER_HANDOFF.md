# DataMend — buyer handoff checklist

## Included in this source package
- Next.js application source and responsive landing page
- Email/password signup and sign-in using Supabase Auth
- Account dashboard with user-specific saved projects
- Browser-local CSV/XLS/XLSX import and cleaning tools
- Private Supabase Storage integration for complete dataset JSON
- Debounced cloud auto-save and project reopen flow in application code
- Supabase schema/migration SQL, environment template and setup notes

## Not included / not yet verified
- Production domain, hosting account or configured Supabase credentials
- Payment processing / subscriptions
- Password reset and custom transactional email provider setup
- Automated test suite, independent security audit or production monitoring
- Paying customers, revenue, or any guaranteed commercial performance
- A successful production build or end-to-end test in this delivery environment

## Transfer checklist
1. Transfer source repository and deployment project.
2. Transfer domain only if owned and explicitly included in the sale.
3. Buyer creates a new Supabase project or formally transfers project ownership.
4. Run `supabase/schema.sql` on the buyer's database.
5. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in the buyer's deployment environment.
6. Configure Supabase Auth site URL, redirect URLs and email delivery.
7. Rotate all secrets and API keys; never put a service-role key in browser code.
8. Test signup, email confirmation, sign-in, per-user isolation, auto-save, reopen and deletion/retention procedures.
9. Confirm dependency and asset licenses.
10. Agree in writing on IP transfer, exclusions, support period and liability.
